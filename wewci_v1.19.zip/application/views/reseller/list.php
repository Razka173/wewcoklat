<?php 
echo "ini adalah halaman reseller";
?>