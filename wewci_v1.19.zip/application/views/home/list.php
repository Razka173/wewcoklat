<?php  
// Load slider
include('slider.php');
// load kategori/banner
// include('kategori.php');
// load data produk
include('produk.php');
// load berita
include('berita.php')
?>