<!-- Banner -->
<section class="banner bgwhite p-t-40 p-b-40">
<div class="container">
<div class="row">
	<div class="col-sm-12 col-md-12 col-lg-12">
		<?php foreach($kategori as $kategori) { ?>
		<!-- block1 -->
		<div class="col-md-4">
			<img src="<?php echo base_url() ?>assets/template/images//banner-02.jpg" alt="IMG-BENNER">

			<div class="block1-wrapbtn w-size2">
				<!-- Button -->
				<a href="#" class="flex-c-m size2 m-text2 bg3 hov1 trans-0-4">
					Dresses
				</a>
			</div>
		</div>
		<?php } ?>
		
	</div>

	
	</div>
</div>
</div>
</section>