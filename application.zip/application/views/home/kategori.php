<!-- Banner -->
<section class="banner bgwhite p-t-40 p-b-40">
<div class="container">
<div class="row">
	<div class="col-sm-12 col-md-12 col-lg-12">
	</div>	
</div>
</div>
</section>