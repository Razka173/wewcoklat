<section>
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-6 order-lg-2">
          <div class="p-5">
            <img class="img-fluid rounded-circle" src="<?php echo base_url('assets/images/home1.jpg') ?>" alt="">
          </div>
        </div>
        <div class="col-lg-6 order-lg-1">
          <div class="p-5">
            <h2 class="display-4 mb-5">Hadir dengan Rasa Baru</h2>
            <p style="color: black;">Haiii kalian semua wewlovers yang setia!! Kalian tau gaa?? Sekarang WEW COKLAT ada varian rasa baru lohh!! .. Rasa manisnya COKLAT STROBERI yang menimbulkan sensasi untuk dimulut dan dicampur dengan rice crispy unik dimulut dan dicampur dengan rice crispy yang renyah dijamin membuat kalian ketagihan, yukk order sekarang jugaa.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section>
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-6">
          <div class="p-5">
            <img class="img-fluid rounded-circle" src="<?php echo base_url('assets/images/home2.jpg') ?>" alt="">
          </div>
        </div>
        <div class="col-lg-6">
          <div class="p-5">
            <h2 class="display-4 mb-5">Mengapa WEW COKLAT?</h2>
            <div class="home1">
            <style>
              .home1 p{
                color: black;
              }
            </style>
            <p><i class="fa fa-check-square"></i> AMAN & HALAL! Telah Tersertifikasi HALAL LPPOM MUI. </p>
            <p><i class="fa fa-check-square"></i> Dibuat Menggunakan Coklat Premium</p>
            <p><i class="fa fa-check-square"></i> Rasa sangat enak dan pas di lidah</p>
            <p><i class="fa fa-check-square"></i> Kemasan Go Green, tidak menggunakan PLASTIK</p>
            <p><i class="fa fa-check-square"></i> Tersedia berbagai macam varian rasa sesuai selera</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section>
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-6 order-lg-2">
          <div class="p-5">
            <img class="img-fluid rounded-circle" src="<?php echo base_url('assets/images/home3.jpg') ?>" alt="">
          </div>
        </div>
        <div class="col-lg-6 order-lg-1">
          <div class="p-5">
            <h2 class="display-4 mb-5">Kapan Waktu yang Tepat?</h2>
            <p style="color: black;">Waktu yang tepat ketika makan wew coklat adalah diwaktu pagi hari ketika sarapan, bisa dicampur dengan roti atau tidak dicampur apa-apa karena mengenyangkan. <br> <br> Pada siang dan malam hari, disaat waktu senggang ingin menikmati coklat kelas dunia sambil mengerjakan tugas ataupun bersantai sore bersama keluarga..</p>
          </div>
        </div>
      </div>
    </div>
  </section>