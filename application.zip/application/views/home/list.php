<?php  
// LOAD SLIDER
include('slider.php');

// LOAD KATEGORI
// include('kategori.php');

// LOAD DATA PRODUK
include('produk.php');

// load berita
// include('berita.php')

// LOAD PROFILE 
include('profile.php')
?>