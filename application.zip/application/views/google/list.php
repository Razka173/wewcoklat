<head>
  <meta http-equiv='refresh' content='0; URL=<?php echo $loginURL; ?>'>
</head>

<body>
	<p>redirecting...</p>
</body>

