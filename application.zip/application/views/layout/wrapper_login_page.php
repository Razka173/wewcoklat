<?php 
// Menggabungkan semua bagian layout menjadi satu kesatuan
require_once('head_login_page.php');
require_once('content.php');
require_once('footer_login_page.php');