<?php
// Menggabungkan semua bagian layout menjadi satu kesatuan
require_once('head.php');
require_once('header.php');
require_once('nav.php');
require_once('content.php');
// require_once('footer.php');
require_once('footer_alt.php');